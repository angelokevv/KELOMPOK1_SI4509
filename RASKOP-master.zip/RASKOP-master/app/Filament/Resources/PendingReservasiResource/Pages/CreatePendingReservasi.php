<?php

namespace App\Filament\Resources\PendingReservasiResource\Pages;

use App\Filament\Resources\PendingReservasiResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreatePendingReservasi extends CreateRecord
{
    protected static string $resource = PendingReservasiResource::class;
}
